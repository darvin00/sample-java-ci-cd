package com.example.admin.Service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.Refund;
import com.razorpay.Utils;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class PaymentService {

    private RazorpayClient razorpayClient;

    public PaymentService() throws Exception {
        this.razorpayClient = new RazorpayClient("rzp_test_TWRDmj35Xa1agr", "glNqRn2OydEAAlPacPDOY2Ek");
    }

    // Create order with dynamic receipt
    public JSONObject createOrder(double amount) throws Exception {
        JSONObject options = new JSONObject();
        options.put("amount", (int) (amount * 100));  // Razorpay expects the amount in paise
        options.put("currency", "INR");

        // Generate a unique receipt ID (you can use UUID or any other method)
        String receiptId = "txn_" + UUID.randomUUID().toString();
        options.put("receipt", receiptId);

        // Create an order in Razorpay and return the order details as a JSONObject
        Order order = razorpayClient.orders.create(options);
        return order.toJson();
    }

    // Verify payment signature
    public boolean verifyPaymentSignature(String razorpayOrderId, String razorpayPaymentId, String razorpaySignature) {
        try {
            // Prepare the data to verify the signature
            Map<String, String> data = new HashMap<>();
            data.put("razorpay_order_id", razorpayOrderId);
            data.put("razorpay_payment_id", razorpayPaymentId);
            data.put("razorpay_signature", razorpaySignature);

            // Verify the signature using Razorpay's utility method
            return Utils.verifyPaymentSignature(new JSONObject(data), "glNqRn2OydEAAlPacPDOY2Ek");
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    // Method to fetch Razorpay order status
    public JSONObject fetchRazorpayOrder(String orderId) throws Exception {
        // Fetch the order using RazorpayClient
        Order razorpayOrder = razorpayClient.orders.fetch(orderId);
        return razorpayOrder.toJson();
    }
    // Method to process a refund
    public Refund processRefund(String razorpayPaymentId) throws Exception {
        // Create a JSON object to hold the refund options
        JSONObject options = new JSONObject();
        options.put("payment_id", razorpayPaymentId);

        // Call the Razorpay API to create a refund
        Refund refund = razorpayClient.refunds.create(options);
        return refund; // Return the refund object
    }
}
