package com.example.admin.exception;

public class FileResponseException extends Throwable {
    public FileResponseException(String fileCannotBeUpload) {
    }
}
