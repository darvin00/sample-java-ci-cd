package com.example.admin.Service;

import com.example.admin.Entity.InventoryReport;
import com.example.admin.Entity.SalesReport;
import com.example.admin.Repository.InventoryReportRepository;
import com.example.admin.Repository.SalesReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportsService {

}
