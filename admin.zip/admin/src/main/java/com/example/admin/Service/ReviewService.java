package com.example.admin.Service;

import com.example.admin.Entity.Product;
import com.example.admin.Entity.Review;
import com.example.admin.Entity.User;
import com.example.admin.Repository.ProductRepository;
import com.example.admin.Repository.ReviewRepository;
import com.example.admin.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    // Add a new review (unapproved by default)
    public Review addReview(Review review) {
        User user = userRepository.findById(review.getUser().getId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        review.setUser(user);
        review.setApproved(false);  // New reviews are unapproved by default

        Review savedReview = reviewRepository.save(review);

        updateProductAverageRating(savedReview.getProductId());

        return savedReview;
    }

    // Get approved reviews by product ID - ONLY approved reviews will be sent to frontend
    public List<Review> getReviewsByProductId(Long productId) {
        return reviewRepository.findByProductIdAndApprovedTrue(productId);
    }

    // Calculate average rating for a product
    public double getAverageRating(Long productId) {
        List<Review> reviews = reviewRepository.findByProductIdAndApprovedTrue(productId);
        if (reviews.isEmpty()) {
            return 0.0;
        }
        return reviews.stream()
                .mapToInt(Review::getRating)
                .average()
                .orElse(0.0);
    }

    public void updateProductAverageRating(Long productId) {
        // Fetch approved reviews
        List<Review> reviews = reviewRepository.findByProductIdAndApprovedTrue(productId);


        if (!reviews.isEmpty()) {
            // Calculate average rating
            double averageRating = reviews.stream()
                    .mapToInt(Review::getRating)
                    .average()
                    .orElse(0.0);


            // Fetch and update product
            Product product = productRepository.findById(productId)
                    .orElseThrow(() -> new RuntimeException("Product not found"));

            product.setAverageRating(averageRating);
            productRepository.save(product);  // Save updated product


        } else {

        }
    }


    // Approve a review by admin
    public Review approveReview(Long reviewId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new RuntimeException("Review not found"));

        review.setApproved(true);  // Approve the review
        reviewRepository.save(review); // Save the review first

        updateProductAverageRating(review.getProductId());  // Update product average rating

        return review; // Return the saved review
    }


    // Edit an existing review (by the review owner) - Only if approved reviews can be shown
    public Review editReview(Long reviewId, Review updatedReview, Long userId) {
        Review existingReview = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new RuntimeException("Review not found"));

        if (!existingReview.getUser().getId().equals(userId)) {
            throw new RuntimeException("User is not authorized to edit this review");
        }

        existingReview.setRating(updatedReview.getRating());
        existingReview.setComment(updatedReview.getComment());

        return reviewRepository.save(existingReview);
    }

    // Delete a review (by the review owner)
    public void deleteReview(Long reviewId, Long userId) {
        Review existingReview = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new RuntimeException("Review not found"));

        if (!existingReview.getUser().getId().equals(userId)) {
            throw new RuntimeException("User is not authorized to delete this review");
        }

        reviewRepository.delete(existingReview);
    }
    public List<Review> getAllReviews() {
        return reviewRepository.findAll();  // Fetch all reviews
    }
}