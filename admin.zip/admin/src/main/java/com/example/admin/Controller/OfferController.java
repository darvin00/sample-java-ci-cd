package com.example.admin.Controller;

import com.example.admin.Service.OfferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/offers")
public class OfferController {

    @Autowired
    private OfferService offerService;

    // Create or update offer
    @PostMapping("/create")
    public ResponseEntity<Map<String, String>> createOffer(@RequestParam Long productId, @RequestParam String offerDescription, @RequestParam Integer durationInHours) {
        offerService.createOrUpdateOffer(productId, offerDescription, durationInHours);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Offer created/updated successfully");
        return ResponseEntity.ok(response);
    }

    @PutMapping("/edit/{offerId}")
    public ResponseEntity<Map<String, String>> editOffer(
            @PathVariable Long offerId,
            @RequestParam String newDescription,
            @RequestParam Integer newDuration) {

        offerService.editOffer(offerId, newDescription, newDuration);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Offer updated successfully");
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/delete/{offerId}")
    public ResponseEntity<Map<String, String>> deleteOffer(@PathVariable Long offerId) {
        offerService.deleteOffer(offerId);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Offer deleted successfully");
        return ResponseEntity.ok(response);
    }

    // Get all offers
    @GetMapping("/all")
    public ResponseEntity<List<Map<String, Object>>> getAllOffers() {
        return ResponseEntity.ok(offerService.getAllOffers());
    }

}