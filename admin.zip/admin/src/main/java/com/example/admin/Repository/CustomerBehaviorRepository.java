package com.example.admin.Repository;

import com.example.admin.Entity.CustomerBehavior;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerBehaviorRepository extends JpaRepository<CustomerBehavior, Long> {
}
