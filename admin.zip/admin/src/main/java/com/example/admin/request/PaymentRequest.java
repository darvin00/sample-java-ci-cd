package com.example.admin.request;

public class PaymentRequest {
    private String orderId;

    // Getter and Setter
    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
