package com.example.admin.Service;

import com.example.admin.Entity.Product;
import com.example.admin.Entity.User;
import com.example.admin.Repository.ProductRepository;
import com.example.admin.Repository.UserRepository;
import com.example.admin.request.ProductResponseDTO;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class FavoriteService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    @Value("${base.url}")
    private String baseUrl;

    public boolean addProductToFavorites(Long userId, Long productId) {
        Optional<User> userOptional = userRepository.findById(userId);
        Optional<Product> productOptional = productRepository.findById(productId);

        if (userOptional.isPresent() && productOptional.isPresent()) {
            User user = userOptional.get();
            Product product = productOptional.get();

            user.getFavorites().add(product);
            userRepository.save(user);
            return true; // Indicate success
        }
        return false; // Indicate failure
    }

    @Transactional
    public boolean removeProductFromFavorites(Long userId, Long productId) {
        Optional<User> userOptional = userRepository.findById(userId);
        Optional<Product> productOptional = productRepository.findById(productId);

        if (userOptional.isPresent() && productOptional.isPresent()) {
            User user = userOptional.get();
            Product product = productOptional.get();

            user.getFavorites().remove(product);
            userRepository.save(user);
            return true; // Indicate success
        }
        return false; // Indicate failure
    }

    @Transactional
    public Set<ProductResponseDTO> getFavorites(Long userId) {
        return userRepository.findByIdWithFavorites(userId)
                .map(user -> user.getFavorites().stream()
                        .map(this::convertToProductResponseDTO)
                        .collect(Collectors.toSet()))
                .orElse(Collections.emptySet()); // Return an empty set if the user is not found
    }

    private ProductResponseDTO convertToProductResponseDTO(Product product) {
        // Create and return a ProductResponseDTO using the product and baseUrl
        return new ProductResponseDTO(product, baseUrl);
    }


}