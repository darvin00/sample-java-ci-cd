package com.example.admin.Controller;

import com.example.admin.DTO.CardDTO;
import com.example.admin.DTO.ImageDTO;
import com.example.admin.DTO.ProductDTO;
import com.example.admin.Entity.Card;
import com.example.admin.Entity.Product;
import com.example.admin.Repository.ProductRepository;
import com.example.admin.Service.*;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@RestController

@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private  UserService userService;
    @Autowired
    private FavoriteService favoriteService;

    @Autowired
    private ReviewService reviewService;

    @Autowired
    private CartService cartService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private MinioClient minioClient;

    @Autowired
    private ProductRepository productRepository;
    @Value("${base.url}") // Add this line to read the base URL from application.properties
    private String baseUrl;


    @Value("${minio.bucket}")
    private String bucketName;
    @PostMapping("/add")
    public ResponseEntity<Product> uploadImage(
            @RequestParam("images") List<MultipartFile> images,
            @RequestParam("mainImage") MultipartFile mainImage,
            @RequestParam("thumbnail") MultipartFile thumbnail,
            @RequestParam(value ="threeDImages",required = false) List<MultipartFile> threeDImages,
            @RequestParam(value = "cardImages", required = false) List<MultipartFile> cardImages,
            @RequestPart("product") Product product) {
        try {
            // Process and upload images
            String mainImageFileName = uploadSingleImage(mainImage, "Main Image");
            product.setMainimage(mainImageFileName);

            String thumbnailFileName = uploadSingleImage(thumbnail, "Thumbnail Image");
            product.setThumbnail(thumbnailFileName);

            List<String> threeDImageFileNames = new ArrayList<>();
            if (threeDImages != null && !threeDImages.isEmpty()) {
                for (MultipartFile image : threeDImages) {
                    threeDImageFileNames.add(uploadSingleImage(image, "3D Image"));
                }
                product.setThreeDImages(threeDImageFileNames);
            } else {
                // If no 3D images are provided, set an empty list or handle as required
                product.setThreeDImages(new ArrayList<>());
            }
            List<String> additionalImageFileNames = new ArrayList<>();
            for (MultipartFile image : images) {
                additionalImageFileNames.add(uploadSingleImage(image, "Additional Image"));
            }
            product.setImages(additionalImageFileNames);

            // Handle card images, titles, and texts
            List<Card> cards = product.getCards();
            if (cardImages != null && !cardImages.isEmpty() && cards != null) {
                for (int i = 0; i < cardImages.size(); i++) {
                    if (i < cards.size()) {
                        MultipartFile cardImage = cardImages.get(i);
                        String cardImageFileName = uploadSingleImage(cardImage, "Card Image");
                        cards.get(i).setImage(cardImageFileName);
                    }
                }
            }
            product.setCards(cards);

            Product savedProduct = productService.addProduct(product);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedProduct);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    private String uploadSingleImage(MultipartFile file, String imageType) throws Exception {
        if (file != null && !file.isEmpty()) {
            String uniqueFileName = generateUniqueFileName(file.getOriginalFilename());
            InputStream inputStream = file.getInputStream();

            PutObjectArgs args = PutObjectArgs.builder()
                    .bucket(bucketName)
                    .object(uniqueFileName) // Use unique file name here
                    .stream(inputStream, file.getSize(), -1)
                    .contentType(file.getContentType())
                    .build();

            minioClient.putObject(args);

            return uniqueFileName; // Return the uploaded file name
        } else {

            return null;
        }
    }

    private String generateUniqueFileName(String originalFileName) {
        // Generate a timestamp and random string for the unique filename
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String timestamp = sdf.format(new Date());

        StringBuilder randomString = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            randomString.append(random.nextInt(36) < 10 ? (char) ('0' + random.nextInt(10)) : (char) ('a' + random.nextInt(26)));
        }

        // Optionally extract the file extension from the original file name
        String extension = "";
        if (originalFileName != null && originalFileName.contains(".")) {
            extension = originalFileName.substring(originalFileName.lastIndexOf("."));
        }

        return timestamp + randomString + extension;
    }

    public static void main(String[] args) {
        SpringApplication.run(ProductController.class, args);
    }



    // Get all products
    @GetMapping("/getall")
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = productService.getAllProducts();
        return ResponseEntity.ok(products);
    }

    // Get product by ID
    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        try {
            Product product = productService.getProductById(id);
            return ResponseEntity.ok(product);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Product> updateProduct(
            @PathVariable Long id, // This is the ID of the product to be updated
            @RequestParam(value = "images", required = false) List<MultipartFile> images,
            @RequestParam(value = "mainImage", required = false) MultipartFile mainImage,
            @RequestParam(value = "thumbnail", required = false) MultipartFile thumbnail,
            @RequestParam(value = "threeDImages", required = false) List<MultipartFile> threeDImages,
            @RequestParam(value = "cardImages", required = false) List<MultipartFile> cardImages,
            @RequestPart("product") Product product) {
        try {
            // Fetch existing product from the database using the provided ID
            Product existingProduct = productService.getProductById(id);
            if (existingProduct == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }

            // Update existing product fields with values from the provided product object
            if (product.getName() != null) existingProduct.setName(product.getName());
            if (product.getDescription() != null) existingProduct.setDescription(product.getDescription());
            if (product.getPrice() != null) existingProduct.setPrice(product.getPrice());
            if (product.getDiscount() != null) existingProduct.setDiscount(product.getDiscount());
            if (product.getStockQuantity() != null) existingProduct.setStockQuantity(product.getStockQuantity());
            if (product.getCategory() != null) existingProduct.setCategory(product.getCategory());
            if (product.getSubcategory() != null) existingProduct.setSubcategory(product.getSubcategory());
            if (product.getSize() != null) existingProduct.setSize(product.getSize());
            if (product.getFeature() != null) existingProduct.setFeature(product.getFeature());
            if (product.getBenefit() != null) existingProduct.setBenefit(product.getBenefit());
            if (product.getSuitable() != null) existingProduct.setSuitable(product.getSuitable());
            if (product.getKeybenefit() != null) existingProduct.setKeybenefit(product.getKeybenefit());
            if (product.getHowToUse() != null) existingProduct.setHowToUse(product.getHowToUse());
            if (product.getIngredients() != null) existingProduct.setIngredients(product.getIngredients());
            if (product.getAverageRating() != null) existingProduct.setAverageRating(product.getAverageRating());
            if (product.getTrend() != null) existingProduct.setTrend(product.getTrend());
            if (product.getSpecial() != null) existingProduct.setSpecial(product.getSpecial());
            if (product.getSpecialLine() != null) existingProduct.setSpecialLine(product.getSpecialLine());
            if (product.getColor() != null) existingProduct.setColor(product.getColor());

            // Handle images if provided
            if (mainImage != null) {
                String mainImageFileName = uploadSingleImage(mainImage, "Main Image");
                existingProduct.setMainimage(mainImageFileName);
            }

            if (thumbnail != null) {
                String thumbnailFileName = uploadSingleImage(thumbnail, "Thumbnail Image");
                existingProduct.setThumbnail(thumbnailFileName);
            }

            if (threeDImages != null) {
                List<String> threeDImageFileNames = new ArrayList<>();
                for (MultipartFile image : threeDImages) {
                    threeDImageFileNames.add(uploadSingleImage(image, "3D Image"));
                }
                existingProduct.setThreeDImages(threeDImageFileNames);
            }

            if (images != null) {
                List<String> additionalImageFileNames = new ArrayList<>();
                for (MultipartFile image : images) {
                    additionalImageFileNames.add(uploadSingleImage(image, "Additional Image"));
                }
                existingProduct.setImages(additionalImageFileNames);
            }

            // Handle card images, titles, and texts if provided
            List<Card> existingCards = existingProduct.getCards();

            if (cardImages != null) {
                // Update existing cards or add new ones based on the number of card images provided
                for (int i = 0; i < cardImages.size(); i++) {
                    MultipartFile cardImage = cardImages.get(i);
                    String cardImageFileName = uploadSingleImage(cardImage, "Card Image");

                    // Check if the card exists and update or create a new one
                    if (i < existingCards.size()) {
                        // Update existing card image
                        Card existingCard = existingCards.get(i);
                        existingCard.setImage(cardImageFileName);
                        // Update title and text if available
                        existingCard.setTitle(product.getCards().get(i).getTitle()); // Ensure that titles are available in product
                        existingCard.setText(product.getCards().get(i).getText()); // Ensure that texts are available in product
                    } else {
                        // Create a new card if there are more images than existing cards
                        Card newCard = new Card();
                        newCard.setImage(cardImageFileName);
                        newCard.setTitle(product.getCards().get(i).getTitle()); // Ensure that titles are available in product
                        newCard.setText(product.getCards().get(i).getText()); // Ensure that texts are available in product
                        existingCards.add(newCard);
                    }
                }
            }

            // Set the updated cards back to the product
            existingProduct.setCards(existingCards);

            // Save the updated product entity to the database
            Product updatedProduct = productService.updateProduct(existingProduct);

            // Return the updated product details in the response
            return ResponseEntity.ok(updatedProduct);

        } catch (Exception e) {
            // Handle exceptions accordingly
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }


    // Delete product
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteProduct(@PathVariable Long id) {
        try {
            // Check if the product exists first
            Optional<Product> product = Optional.ofNullable(productService.getProductById(id));
            if (!product.isPresent()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Product not found with ID: " + id);
            }

            // Remove related entries in the favorite table
            userService.removeProductFromFavorites(id);

            // Remove related entries in the order table if any exist
            orderService.removeOrdersByProductId(id);

            // Remove related entries in the cart table
            cartService.removeProductFromCartByProductId(id);

            // Now, delete the product
            productService.deleteProduct(id);

            return ResponseEntity.ok("Product deleted successfully");
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Product not found with ID: " + id);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error deleting product: " + e.getMessage());
        }
    }



    @GetMapping("/json")
    public ResponseEntity<List<ProductDTO>> getProductsAsJson() {
        try {
            List<Product> products = productService.getAllProducts();
            List<ProductDTO> jsonOutput = products.stream()
                    .map(this::convertToDTO)
                    .collect(Collectors.toList());
            return ResponseEntity.ok(jsonOutput);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    private ProductDTO convertToDTO(Product product) {
        ProductDTO dto = new ProductDTO();
        dto.setId(product.getId());
        dto.setCategory(product.getCategory());

        dto.setShine(product.getShine());
        dto.setSheShine(product.getSheShine());
        dto.setSubcategory(product.getSubcategory());

        // Convert cards to DTO format
        if (product.getCards() != null) {
            dto.setCards(convertCardsToDTO(product.getCards()));
        }

        dto.setMainimage(baseUrl + "/" + product.getMainimage());
        dto.setThumbnail(baseUrl + "/" + product.getThumbnail());
        dto.setImages(product.getImages().stream().map(image -> baseUrl + "/" + image).collect(Collectors.toList()));
        dto.setThreeDImages(product.getThreeDImages().stream().map(image -> baseUrl + "/" + image).collect(Collectors.toList()));
        dto.setTitle(product.getTitle());
        dto.setName(product.getName());
        dto.setBenefit(product.getBenefit());
        dto.setSuitable(product.getSuitable());
        dto.setDescription(product.getDescription());
        dto.setKeybenefit(product.getKeybenefit());
        dto.setHowToUse(product.getHowToUse());
        dto.setIngredients(product.getIngredients());
        dto.setSize(product.getSize());
        dto.setMrp(product.getMrp());
        dto.setPrice(product.getPrice());
        dto.setStockQuantity(product.getStockQuantity());
        dto.setDiscount(product.getDiscount());
        dto.setAverageRating(product.getAverageRating());
        dto.setFeature(product.getFeature());
        dto.setTrend(product.getTrend());
        dto.setSpecial(product.getSpecial());
        dto.setSpecialLine(product.getSpecialLine());
        dto.setColor(product.getColor());

        return dto;
    }

    private List<CardDTO> convertCardsToDTO(List<Card> cards) {
        return cards.stream().map(card -> {
            CardDTO cardDTO = new CardDTO();
            cardDTO.setId(card.getId());
            cardDTO.setText(card.getText());
            cardDTO.setTitle(card.getTitle());
            cardDTO.setImage(baseUrl + "/" + card.getImage());
            return cardDTO;
        }).collect(Collectors.toList());
    }
    private void updateProductDetails(Product existingProduct, Product updatedProduct) {
        existingProduct.setTitle(updatedProduct.getTitle());
        existingProduct.setDescription(updatedProduct.getDescription());
        existingProduct.setPrice(updatedProduct.getPrice());
        existingProduct.setDiscount(updatedProduct.getDiscount());
        existingProduct.setStockQuantity(updatedProduct.getStockQuantity());
        existingProduct.setCategory(updatedProduct.getCategory());
        existingProduct.setSubcategory(updatedProduct.getSubcategory());
        existingProduct.setSize(updatedProduct.getSize());
        existingProduct.setFeature(updatedProduct.getFeature());
        existingProduct.setBenefit(updatedProduct.getBenefit());
        existingProduct.setSuitable(updatedProduct.getSuitable());
        existingProduct.setMainimage(baseUrl + "/" + updatedProduct.getMainimage());
        existingProduct.setThumbnail(baseUrl + "/" + updatedProduct.getThumbnail());
        existingProduct.setImages(updatedProduct.getImages().stream().map(image -> baseUrl + "/" + image).collect(Collectors.toList()));
        existingProduct.setThreeDImages(updatedProduct.getThreeDImages().stream().map(image -> baseUrl + "/" + image).collect(Collectors.toList()));
        existingProduct.setKeybenefit(updatedProduct.getKeybenefit());
        existingProduct.setHowToUse(updatedProduct.getHowToUse());
        existingProduct.setIngredients(updatedProduct.getIngredients());
        existingProduct.setAverageRating(updatedProduct.getAverageRating());
        existingProduct.setCards(updatedProduct.getCards());
        existingProduct.setTrend(updatedProduct.getTrend());
        existingProduct.setSpecial(updatedProduct.getSpecial());
        existingProduct.setSpecialLine(updatedProduct.getSpecialLine());
        existingProduct.setColor(updatedProduct.getColor());
    }
    @GetMapping("/low-stock")
    public List<Product> getLowStockProducts() {
        return productService.getLowStockProducts();
    }
    @GetMapping("/allimages")
    public ResponseEntity<List<ImageDTO>> getAllImages() {
        try {
            List<Product> products = productService.getAllProducts();
            List<ImageDTO> images = new ArrayList<>();

            for (Product product : products) {
                // Add main image
                if (product.getMainimage() != null) {
                    images.add(new ImageDTO(  product.getMainimage()));
                }

                // Add thumbnail image
                if (product.getThumbnail() != null) {
                    images.add(new ImageDTO( product.getThumbnail()));
                }

                // Add additional images
                if (product.getImages() != null) {
                    for (String image : product.getImages()) {
                        images.add(new ImageDTO( image));
                    }
                }

                // Add 3D images
                if (product.getThreeDImages() != null) {
                    for (String image : product.getThreeDImages()) {
                        images.add(new ImageDTO(image));
                    }
                }

                // Add card images
                if (product.getCards() != null) {
                    for (Card card : product.getCards()) {
                        if (card.getImage() != null) {
                            images.add(new ImageDTO( card.getImage()));
                        }
                    }
                }
            }

            return ResponseEntity.ok(images);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }



}