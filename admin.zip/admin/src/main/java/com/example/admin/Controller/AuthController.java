package com.example.admin.Controller;

import com.example.admin.Entity.User;
import com.example.admin.Repository.UserRepository;
import com.example.admin.Service.EmailService;
import com.example.admin.Service.ProfileImageService;
import com.example.admin.Service.UserService;
import com.example.admin.request.LoginRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/users")
// Cross-origin for Angular app
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProfileImageService profileImageService;

    // ------------------ Registration Endpoints ------------------ //
    @PostMapping("/register")
    public ResponseEntity<Map<String, String>> register(@RequestBody User user) {
        Map<String, String> response = new HashMap<>();

        // Check if the user already exists
        if (userRepository.existsByEmail(user.getEmail())) {
            response.put("message", "Email already exists");
            return ResponseEntity.badRequest()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(response); // Return JSON response
        }

        // Generate profile image as a byte array (based on name and email)
        byte[] avatarImage = profileImageService.generateProfileImage(user.getEmail());
        user.setAvatarUrl(avatarImage);  // Store image as byte array

        // Generate a verification token (instead of OTP)
        String verificationToken = UUID.randomUUID().toString();
        user.setVerificationToken(verificationToken);
        user.setTokenGeneratedTime(LocalDateTime.now()); // Set token generation time
        user.setIsVerified(false); // Set verified to false by default

        // Save the user with the verification token
        userRepository.save(user);

        // Create verification link
        String verificationLink = "http://192.168.0.219:4200/verify?token=" + user.getVerificationToken();

        // Send the verification email with the link
        String subject = "Verify Your Email Address to Complete Your Signup!";
        String message = "Dear User ,<br><br>"+"Thank you for signing up with KPM Super Shopee! <br>To complete your registration and start exploring a world of exciting products, we need to verify your email address.<br><br> "
                +"<b>Click the link below to verify your email:</b>"+ verificationLink+"<br><br>"+"Why verify your email?"+"<br><br>"+
                "Secure your account Receive order updates and special offers" +
                "Access exclusive deals and features" +
                "If you didn’t create this account, please ignore this email.<br><br>"
                +"For any questions or support, feel free to contact us at <br> <b>Email :</b>shineorganicskpm@gmail.com<br>" +
                "<b>Phone : </b>+91 97915 47470.<br><br>" +"Thank you for joining the <b>KPM Super Shopee family!</b>"
                +"<br><br>Warm regards,<br>KPM Super Shopee Team";
        emailService.sendEmail(user.getEmail(), subject, message);

        // Prepare success response
        response.put("message", "Verification email sent to your email address.");
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(response);  // Return JSON response
    }
    // ------------------ verification Endpoints ------------------ //
    @GetMapping("/verify")
    public ResponseEntity<Map<String, String>> verifyUser(@RequestParam("token") String token) {
        // Find the user by the verification token
        Optional<User> userOptional = userRepository.findByVerificationToken(token);

        if (userOptional.isPresent()) {
            User user = userOptional.get();

            // Check if the token is expired (optional)
            if (user.getTokenGeneratedTime().isBefore(LocalDateTime.now().minusHours(24))) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Verification link expired."));
            }

            // Mark user as verified
            user.setIsVerified(true);
            user.setVerificationToken(null); // Remove the token after verification
            userRepository.save(user);

            return ResponseEntity.ok(Map.of("message", "Account successfully verified."));
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Invalid verification token."));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody LoginRequest loginRequest) {
        // Find the user by email and password
        Optional<User> userOptional = userService.login(loginRequest.getEmail(), loginRequest.getPassword());

        // Check if the user exists (email and password combination is correct)
        if (userOptional.isPresent()) {
            User user = userOptional.get();

            // Check if the user is verified
            if (Boolean.TRUE.equals(user.getIsVerified())) {
                // If verified, allow login
                return ResponseEntity.ok(user);
            } else {
                // If not verified, send verification email and return a forbidden response
                String verificationLink = "http://192.168.0.219:4200/verify?token=" + user.getVerificationToken();
                String subject = "Account Verification Reminder";
                String message = "Dear User"+",<br><br>"
                        +"It seems you haven’t verified your email address yet. <br>To activate your account and enjoy a seamless shopping experience at KPM Super Shopee, we kindly request you to verify your email."
                        +"<br>Click the link below to verify your email now:<br> " + verificationLink+"<br><br>"+"Why is this important?<br>"
                        +"-Access your account and explore amazing products<br>" +
                        "-Receive order updates and exclusive deals<br>" +
                        "-Ensure the security of your account<br><br>" +
                        "If you have already verified your email, please disregard this message. If not, we encourage you to verify it as soon as possible to activate your account.<br>"+
                        "For any assistance, feel free to reach out to us at <b>Email :</b>shineorganicskpm@gmail.com<br><b>Phone : </b>+91 97915 47470.<br><br>"
                        +"Thank you for choosing <b>KPM Super Shopee!</b><br><br>" +
                        "Warm regards,<br>" +
                        "KPM Super Shopee Team";
                emailService.sendEmail(user.getEmail(), subject, message);

                Map<String, String> response = new HashMap<>();
                response.put("message", "Account is not verified. A verification email has been resent.");
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(response);  // Return JSON response
            }
        } else {
            // Return a JSON error response when login fails
            Map<String, String> response = new HashMap<>();
            response.put("message", "Invalid email or password.");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(response);  // Return JSON response
        }
    }

    // ------------------ Profile Endpoints ------------------ //

    @GetMapping("/profile")
    public ResponseEntity<Map<String, Object>> getUserProfileByEmail(@RequestParam String email) {
        Optional<User> userOpt = userService.getUserByEmail(email);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            Map<String, Object> response = new HashMap<>();
            response.put("id", user.getId());
            response.put("name", user.getName());
            response.put("email", user.getEmail());
            response.put("mobileNumber", user.getMobileNumber());
            response.put("dob", user.getDob());
            response.put("gender", user.getGender());
            response.put("avatarUrl", Base64.getEncoder().encodeToString(user.getAvatarUrl()));  // Convert byte[] to base64 string
            response.put("address", user.getAddresses());

            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, String>> updateProfileById(
            @PathVariable Long id,
            @RequestPart("user") String userJson,  // User data as JSON
            @RequestPart(value = "avatar", required = false) MultipartFile avatarFile) {

        // Convert the JSON string to a User object using ObjectMapper
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule()); // Handle LocalDate if required

        User updatedUser;
        try {
            updatedUser = objectMapper.readValue(userJson, User.class); // Deserialize JSON to User
        } catch (JsonProcessingException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Invalid user data format: " + e.getMessage()));
        }

        // Fetch the existing user by ID
        Optional<User> existingUserOpt = userService.getUserById(id);
        if (existingUserOpt.isPresent()) {
            User existingUser = existingUserOpt.get();

            // Update fields
            existingUser.setName(updatedUser.getName());
            existingUser.setEmail(updatedUser.getEmail());
            existingUser.setMobileNumber(updatedUser.getMobileNumber());
            existingUser.setDob(updatedUser.getDob());
            existingUser.setGender(updatedUser.getGender());
            existingUser.setAddresses(updatedUser.getAddresses());

            // Handle avatar file
            if (avatarFile != null && !avatarFile.isEmpty()) {
                try {
                    byte[] avatar = avatarFile.getBytes();
                    existingUser.setAvatarUrl(avatar); // Update avatar
                } catch (IOException e) {
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body(Map.of("error", "Error uploading avatar"));
                }
            }

            userService.saveUser(existingUser); // Save the updated user
            return ResponseEntity.ok(Map.of("message", "User profile updated successfully"));
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "User with id " + id + " not found"));
        }
    }

    // ------------------ Password Management Endpoints ------------------ //

    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestParam String email) {
        Optional<User> userOpt = userRepository.findByEmail(email);
        if (userOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "User not found."));
        }

        emailService.sendPasswordResetInstructions(email);
        return ResponseEntity.ok(Map.of("message", "Password reset instructions sent."));
    }

    // ------------------ Reset Password Management Endpoints ------------------ //

    @PutMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestParam String email, @RequestParam String newPassword) {
        Optional<User> userOpt = userRepository.findByEmail(email);
        if (userOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found.");
        }

        User user = userOpt.get();
        user.setPassword(newPassword);  // Password should be hashed in production
        userRepository.save(user);

        return ResponseEntity.ok(Map.of("message", "Password reset successfully."));
    }
}
