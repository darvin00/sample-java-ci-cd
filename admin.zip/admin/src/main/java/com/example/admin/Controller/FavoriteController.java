package com.example.admin.Controller;

import com.example.admin.Service.FavoriteService;
import com.example.admin.request.ProductResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/api/favorites")
public class FavoriteController {
    @Autowired
    private FavoriteService favoriteService;

    @PostMapping("/{userId}/{productId}")
    public ResponseEntity<Map<String, String>> addProductToFavorites(@PathVariable Long userId, @PathVariable Long productId) {
        favoriteService.addProductToFavorites(userId, productId);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Product added to favorites");
        return ResponseEntity.ok(response);
    }


    @DeleteMapping("/{userId}/{productId}")
    public ResponseEntity<String> removeProductFromFavorites(@PathVariable Long userId, @PathVariable Long productId) {
        favoriteService.removeProductFromFavorites(userId, productId);
        return ResponseEntity.ok().header("Content-Type", "application/json").body("{\"message\":\"Product removed from favorites\"}");
    }


    @GetMapping("/{userId}")
    public ResponseEntity<Set<ProductResponseDTO>> getFavorites(@PathVariable Long userId) {
        Set<ProductResponseDTO> favorites = favoriteService.getFavorites(userId);
        return ResponseEntity.ok(favorites);
    }
}
