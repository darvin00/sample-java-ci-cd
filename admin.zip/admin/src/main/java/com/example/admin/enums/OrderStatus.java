package com.example.admin.enums;

public enum OrderStatus {
    PENDING, SHIPPED, DELIVERED, CANCELED
}