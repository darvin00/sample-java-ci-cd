package com.example.admin.Controller;

import com.example.admin.Entity.Review;
import com.example.admin.Entity.User;
import com.example.admin.Service.EmailService;
import com.example.admin.Service.ReviewService;
import com.example.admin.Service.UserService;
import com.example.admin.request.ReviewResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reviews")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private UserService userService; // Add this to fetch the user
    @Value("${admin.email}")
    private String adminEmail;

    @PostMapping("/add")
    public ResponseEntity<ReviewResponse> addReview(@RequestBody Map<String, Object> payload) {
        // Extract fields from the payload
        Long userid = Long.valueOf(payload.get("userid").toString());
        Long productId = Long.valueOf(payload.get("productId").toString());
        Integer rating = Integer.valueOf(payload.get("rating").toString());
        String comment = (String) payload.get("comment");

        // Fetch the complete User entity from the database using the userId
        User user = userService.findUserById(userid);

        // Create a new Review object and set the extracted values
        Review review = new Review();
        review.setRating(rating);
        review.setComment(comment);
        review.setProductId(productId);
        review.setUser(user);

        Review savedReview = reviewService.addReview(review);
        reviewService.updateProductAverageRating(savedReview.getProductId());

        // Send an email notification to the user for approval status
        String userSubject = "Your Product Review is Under Review!";
        String userText = "Dear " + user.getName() + ",<br><br>"
                + "Thank you for taking the time to share your feedback on KPM Products !" +
                "<br>We’ve received your review and are currently in the process of reviewing it to ensure it meets our platform standards.. <br><br>"+
                "Once your review is approved by our team, it will be published on the product page and visible to other shoppers.<br><br>"+
                  "We appreciate your patience and your contribution to making KPM Super Shopee a trusted shopping destination. <br>If you have any questions, feel free to contact us at <br> <b>Email :</b>shineorganicskpm@gmail.com"+"<br>"+
                        "<b>Phone : </b>+91 97915 47470.<br><br>"+"Thank you for being an important part of our community!<br><br>"+
                "Best regards,<br>KPM Super Shopee Team<br>";
        emailService.sendEmail(user.getEmail(), userSubject, userText);

        // Send an email notification to the admin for approval request
        String adminSubject = "Review Submission for Approval on KPM Super Shopee";
        String adminText = "Dear Admin,<br><br>"
                + "A customer has shared their thoughts about a product on KPM Super Shopee. " +
                "Here are the review details:<br><br> "+"<b>User Name:</b>" + user.getName() + "<br> <b>Product Id: </b> " + productId+"<br>"
                + "Please review and approve this submission to ensure it meets our platform standards.<br><br>"+
                "You can manage the review through the admin panel here: http://192.168.0.219:4200/dashboard/adminreview"+""+"<br><br>"+"Thank you for ensuring that KPM Super Shopee remains a trusted shopping destination!<br><br>"
                + "Best regards,<br> KPM Super Shopee Team <br> ";
        emailService.sendEmail(adminEmail, adminSubject, adminText);

        ReviewResponse reviewResponse = new ReviewResponse(
                savedReview.getId(),
                savedReview.getRating(),
                savedReview.getComment(),
                savedReview.getProductId(),
                user.getId(),
                user.getName(),
                user.getAvatarUrl(),
                savedReview.isApproved()
        );

        return ResponseEntity.ok(reviewResponse);
    }


    @GetMapping("/product/{productId}")
    public ResponseEntity<List<ReviewResponse>> getReviewsByProductId(@PathVariable Long productId) {
        List<Review> reviews = reviewService.getReviewsByProductId(productId);
        List<ReviewResponse> response = reviews.stream().map(review -> new ReviewResponse(
                        review.getId(),
                        review.getRating(),
                        review.getComment(),
                        review.getProductId(),
                        review.getUser().getId(),
                        review.getUser().getName(),
                        review.getUser().getAvatarUrl(), // Avatar assumed to be byte[]
                        review.isApproved()
                ))
                .toList();
        return ResponseEntity.ok(response);
    }

    @GetMapping("/product/{productId}/average")
    public ResponseEntity<Double> getAverageRating(@PathVariable Long productId) {
        return ResponseEntity.ok(reviewService.getAverageRating(productId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Review> editReview(
            @PathVariable Long id,
            @RequestBody Review updatedReview,
            @RequestParam Long userId) {
        Review review = reviewService.editReview(id, updatedReview, userId);
        return ResponseEntity.ok(review);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReview(
            @PathVariable Long id,
            @RequestParam Long userId) {
        reviewService.deleteReview(id, userId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/admin/all")
    public ResponseEntity<List<ReviewResponse>> getAllReviewsForAdmin() {
        List<Review> reviews = reviewService.getAllReviews();
        List<ReviewResponse> response = reviews.stream()
                .map(review -> new ReviewResponse(
                        review.getId(),
                        review.getRating(),
                        review.getComment(),
                        review.getProductId(),
                        review.getUser().getId(),
                        review.getUser().getName(),
                        review.getUser().getAvatarUrl(), // Assuming it's a byte[] here
                        review.isApproved() // Pass the boolean value correctly
                ))
                .toList();

        return ResponseEntity.ok(response);
    }

    @PutMapping("/{id}/approve")
    public ResponseEntity<ReviewResponse> approveReview(@PathVariable Long id) {
        Review approvedReview = reviewService.approveReview(id);

        // Send an email notification to the user upon approval
        User user = approvedReview.getUser();
        String subject = "Your Product Review Has Been Approved!";
        String text = "Dear " + user.getName() + ",<br><br>"
                + "Thank you for sharing your thoughts about on KPM Super Shopee Products !<br> "
                + "We’re excited to let you know that your review has been approved and is now live on our website.<br> " +
                "Your feedback helps others make informed decisions and supports us in delivering the best products to our customers.<br><br>"+
                "Feel free to explore more products and leave reviews. We value your continued support!<br>"+"[Visit KPM Super Shopee Now]<br>"+
                "Thank you for being a valued part of our community.<br><br>"+ "Warm regards,<br>KPM Super Shopee "+"<br><b>Email :</b>shineorganicskpm@gmail.com"+"<br>"+
                "<b>Phone : </b>+91 97915 47470"+"<br><br>";
        emailService.sendEmail(user.getEmail(), subject, text);

        ReviewResponse reviewResponse = new ReviewResponse(
                approvedReview.getId(),
                approvedReview.getRating(),
                approvedReview.getComment(),
                approvedReview.getProductId(),
                user.getId(),
                user.getName(),
                user.getAvatarUrl(),
                approvedReview.isApproved()
        );

        return ResponseEntity.ok(reviewResponse);
    }

}