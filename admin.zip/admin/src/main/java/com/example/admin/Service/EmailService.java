package com.example.admin.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    private static final long EXPIRATION_TIME = 5 * 60 * 1000; // 5 minutes in milliseconds

    // Send an email with HTML content
    public void sendEmail(String to, String subject, String body) {
        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(body, true); // 'true' enables HTML content
            mailSender.send(mimeMessage);
        } catch (MessagingException e) {
            throw new RuntimeException("Failed to send email: " + e.getMessage(), e);
        }
    }

    // Send password reset instructions with a clickable link
    public void sendPasswordResetInstructions(String to) {
        long timestamp = new Date().getTime();
        String encodedTimestamp = URLEncoder.encode(String.valueOf(timestamp), StandardCharsets.UTF_8);

        String resetLink = "http://192.168.0.219:4200/resetpassword?email=" +
                URLEncoder.encode(to, StandardCharsets.UTF_8) +
                "&timestamp=" + encodedTimestamp;

        String message = "<p>Dear User,</p>" +
                "<p>We received a request to reset your password for <b>KPM Super Shopee</b>.</p>" +
                "<p>Click the link below to reset your password:</p>" +
                "<a href='" + resetLink + "'>Reset Password</a>" +
                "<p><b>Note:</b> The link is valid for 5 minutes. If you didn't request this, please ignore this email.</p>" +
                "<p>Warm regards,</p>" +
                "<p><b>KPM Super Shopee Team</b></p>";

        sendEmail(to, "Password Reset Request", message);
    }

    // Check if the password reset link has expired
    public boolean isLinkExpired(String timestamp) {
        try {
            long linkTimestamp = Long.parseLong(timestamp);
            long currentTime = new Date().getTime();
            return (currentTime - linkTimestamp) > EXPIRATION_TIME;
        } catch (NumberFormatException e) {
            return true; // Treat invalid timestamps as expired
        }
    }


    // Send a refund success email
    public void sendRefundSuccessEmail(String customerEmail, Long orderId) {
        String message = "<p>Dear Customer,</p>" +
                "<p>Your payment for order ID <strong>" + orderId + "</strong> has been refunded successfully.</p>" +
                "<p>Thank you for shopping with us.</p>" +
                "<p>Warm regards,</p>" +
                "<p><b>KPM Super Shopee Team</b></p>";
        sendEmail(customerEmail, "Refund Processed Successfully", message);
    }

    // Send an OTP to the user
    public void sendOtp(String recipientEmail, String otp) {
        String message = "<p>Your OTP for verification is: <strong>" + otp + "</strong>.</p>" +
                "<p>The OTP is valid for 5 minutes.</p>";
        sendEmail(recipientEmail, "Your OTP Code", message);
    }

    // Generate a 6-digit OTP
    public String generateOtp() {
        return String.valueOf((int) (Math.random() * 900000) + 100000);
    }

    // Send bulk emails
    public void sendBulkEmail(List<String> recipients, String subject, String message) {
        for (String recipient : recipients) {
            sendEmail(recipient, subject, message);
        }
    }

    // Send promotional offers
    public void sendOfferEmail(String to, String subject, String text) {
        String shopName = "KPM Super Shopee";
        String finalSubject = subject + " - " + shopName;
        String finalText = "<p>" + text + "</p>" +
                "<p>Best regards,</p>" +
                "<p><b>" + shopName + "</b></p>";
        sendEmail(to, finalSubject, finalText);
    }

    public void sendEmailToUsers(List<String> emailAddresses, String subject, String message) {
    }

    public void sendCancellationEmail(String customerEmail, Long orderId) {
        MimeMessage message = mailSender.createMimeMessage();
        try {
            MimeMessageHelper helper = new MimeMessageHelper(message, true); // true means multipart
            helper.setTo(customerEmail);
            helper.setSubject("Update on Your Order Cancellation");

            String htmlContent = "<p>Dear Customer,</p><p>We regret to inform you that your order with Shine Organics Natural Cosmetics has been canceled. This decision was made due to [reason for cancellation, e.g., \"unavailability of stock,\" \"technical issue,\" etc.].</p>"
                    + "<p>If payment has already been made, rest assured that the refund process has been initiated. The amount will be credited to your [payment method] within [time frame].</p>"
                    + "<p>We sincerely apologize for any inconvenience caused and truly appreciate your understanding. Should you need further assistance or wish to explore our other products, please feel free to contact us at:</p>"
                    + "<p><b>Email:</b> shineorganicskpm@gmail.com<br><b>Phone:</b> +91 97915 47470</p>"
                    + "<p>Thank you for choosing Shine Organics Natural Cosmetics. We hope to serve you again soon!</p>"
                    + "<p>Warm regards,<br>Team Shine Organics</p>";

            helper.setText(htmlContent, true);  // true enables HTML content

            mailSender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        }

    }
}