package com.example.admin.DTO;




public class PaymentDto {
    private Long userId;
    private Long orderId;
    private double amount;
    private String paymentMethod; // e.g., "credit_card"
//    private PaymentDetails paymentDetails;

    // Getters and setters
}
