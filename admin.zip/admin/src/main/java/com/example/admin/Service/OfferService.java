package com.example.admin.Service;

import com.example.admin.Entity.Offer;
import com.example.admin.Repository.OfferRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class OfferService {

    @Autowired
    private OfferRepository offerRepository;

    // Create or update an offer
    public void createOrUpdateOffer(Long productId, String offerDescription, Integer durationInHours) {
        Offer offer = new Offer();
        offer.setProductId(productId);
        offer.setOfferDescription(offerDescription);
        offer.setStartTime(LocalDateTime.now());
        offer.setDurationInHours(durationInHours);
        offerRepository.save(offer);
    }

    // Automatically delete expired offers
    @Scheduled(fixedRate = 3600000) // Run every hour
    public void checkAndDeleteExpiredOffers() {
        List<Offer> offers = offerRepository.findAll();

        for (Offer offer : offers) {
            if (offer.getStatus().equals("active") && offer.getStartTime().plusHours(offer.getDurationInHours()).isBefore(LocalDateTime.now())) {
                offer.setStatus("expired");
                offerRepository.save(offer);
            }
        }
    }

    // Delete an offer by ID
    public void deleteOffer(Long offerId) {
        offerRepository.deleteById(offerId);
    }

    // Edit an offer
    public void editOffer(Long offerId, String newDescription, Integer newDuration) {
        Offer offer = offerRepository.findById(offerId).orElseThrow(() -> new RuntimeException("Offer not found"));
        offer.setOfferDescription(newDescription);
        offer.setDurationInHours(newDuration);
        offerRepository.save(offer);
    }

    public List<Map<String, Object>> getAllOffers() {
        return offerRepository.findAll().stream().map(offer -> {
            Map<String, Object> offerMap = new HashMap<>();
            offerMap.put("id", offer.getId());
            offerMap.put("productId", offer.getProductId());
            offerMap.put("offerDescription", offer.getOfferDescription());
            offerMap.put("status", offer.getStatus());
            offerMap.put("timeRemaining", offer.getTimeRemaining()); // Include remaining time
            return offerMap;
        }).collect(Collectors.toList());
    }

}