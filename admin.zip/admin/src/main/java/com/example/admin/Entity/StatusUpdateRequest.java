package com.example.admin.Entity;

public class StatusUpdateRequest {
    private String status;

    // Getters and setters
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

