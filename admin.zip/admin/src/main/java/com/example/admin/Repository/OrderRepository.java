package com.example.admin.Repository;

import com.example.admin.Entity.Order;
import com.example.admin.Entity.User;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface OrderRepository extends JpaRepository<Order, Long> {

    List<Order> findByUserId(Long userId);

    boolean existsByUserIdAndProductId(Long userId, Long productId);
    List<Order> findByUser(User user);

    @Query("SELECT SUM(o.amount) FROM Order o")
    Double calculateTotalSales();

    Optional<Order> findByRazorpayOrderId(String razorpayOrderId);

    void deleteByProductId(Long productId);
}

