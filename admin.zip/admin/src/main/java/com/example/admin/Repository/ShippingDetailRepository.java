package com.example.admin.Repository;

import com.example.admin.Entity.ShippingDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShippingDetailRepository extends JpaRepository<ShippingDetail, Long> {
}
