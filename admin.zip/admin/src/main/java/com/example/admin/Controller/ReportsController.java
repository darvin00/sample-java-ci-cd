package com.example.admin.Controller;

import com.example.admin.Entity.InventoryReport;
import com.example.admin.Entity.SalesReport;
import com.example.admin.Service.ReportsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/reports")
public class ReportsController {

}
