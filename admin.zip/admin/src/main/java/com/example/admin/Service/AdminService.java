package com.example.admin.Service;

import org.springframework.stereotype.Service;

@Service
public class AdminService {

    // Hardcoded admin email and password
    private static final String ADMIN_EMAIL = "admin@gmail.com";
    private static final String ADMIN_PASSWORD = "admin";

    public boolean authenticate(String email, String password) {
        // Check if the provided email and password match the hardcoded credentials
        return ADMIN_EMAIL.equals(email) && ADMIN_PASSWORD.equals(password);
    }
}
