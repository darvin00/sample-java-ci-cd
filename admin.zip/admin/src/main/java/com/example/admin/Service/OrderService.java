package com.example.admin.Service;

import com.example.admin.DTO.OrderDTO;
import com.example.admin.DTO.OrderItemDTO;
import com.example.admin.Entity.*;
import com.example.admin.Repository.*;
import com.example.admin.exception.ProductNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductService productService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AddressRepository addressRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    @Autowired
    private AddressService addressService;

    private String generateInvoiceNumber() {
        // Generate a unique invoice number, e.g., using current timestamp and a random number
        return "INV-" + System.currentTimeMillis() + "-" + (int)(Math.random() * 1000);
    }

    // Method to place an order
    public Order placeOrder(OrderDTO orderDTO) {
        double totalPrice = 0;

        // Create a new order
        Order order = new Order();
        order.setOrderStatus("PENDING");
        order.setPaymentStatus("NOT PAID");
        order.setDeliveryDate(orderDTO.getDeliveryDate());
        order.setOrderDate(LocalDate.now());
        order.setInvoiceNumber(generateInvoiceNumber());
        order.setUser(userService.findUserById(orderDTO.getUserId()));
        order.setOrderAddress(addressService.findById(orderDTO.getAddressId()));

        // Process each order item
        for (OrderItemDTO item : orderDTO.getOrderItems()) {
            Product product = productRepository.findById(item.getProductId())
                    .orElseThrow(() -> new ProductNotFoundException("Product not found with ID: " + item.getProductId()));

            // Check stock availability
            if (product.getStockQuantity() < item.getQuantity()) {
                throw new IllegalArgumentException("Not enough stock available for product: " + product.getName());
            }

            // Update product stock quantity
            product.setStockQuantity(product.getStockQuantity() - item.getQuantity());
            productRepository.save(product);

            // Calculate total price
            totalPrice += product.getPrice() * item.getQuantity();

            // Create and save OrderItem
            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(order);
            orderItem.setProduct(product);
            orderItem.setQuantity(item.getQuantity());
            orderItemRepository.save(orderItem);
        }

        order.setAmount(totalPrice);
        return orderRepository.save(order); // Save the order
    }

    // Fetch all orders placed by a user
    public List<Order> getOrdersByUser(Long userId) {
        if (userId == null) {
            throw new IllegalArgumentException("User ID must be provided");
        }

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        return orderRepository.findByUser(user);
    }

    // Find an order by ID
    public Order findOrderById(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found with ID: " + orderId));
    }

    // Update the order status
    @Transactional
    public Order updateOrderStatus(Long orderId, String status) {
        Order order = findOrderById(orderId);

        if (!isValidStatus(status)) {
            throw new IllegalArgumentException("Invalid order status: " + status);
        }

        order.setOrderStatus(status);
        return orderRepository.save(order);
    }

    private boolean isValidStatus(String status) {
        return List.of("Processing", "Shipped", "Delivered", "Canceled").contains(status);
    }

    // Fetch all orders
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order findOrderByRazorpayOrderId(String razorpayOrderId) {
        return orderRepository.findByRazorpayOrderId(razorpayOrderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found with Razorpay Order ID: " + razorpayOrderId));
    }

    public Order saveOrder(Order order) {
        return orderRepository.save(order);
    }

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public void removeOrdersByProductId(Long productId) {
        orderRepository.deleteByProductId(productId);
    }
}
