package com.example.admin.Controller;

import com.example.admin.DTO.AddressDTO;
import com.example.admin.DTO.OrderDTO;
import com.example.admin.DTO.OrderItemDTO;
import com.example.admin.DTO.ProductDTO;
import com.example.admin.Entity.*;
import com.example.admin.Repository.OrderRepository;
import com.example.admin.Service.*;
import com.example.admin.exception.ResourceNotFoundException;
import com.example.admin.request.PaymentRequest;
import com.razorpay.Refund;
import org.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Value("${base.url}")
    private String baseUrl;

    @Autowired
    private CartService cartService;

    //    @Autowired
//    private InvoiceService invoiceService;
    @Autowired
    private OrderService orderService;

    @Autowired
    private  DashboardService dashboardService;

    @Autowired
    private UserService userService;

    @Autowired
    private AddressService addressService;

    @Autowired
    private ProductService productService;

    @Autowired
    private OrderRepository orderRepository;




    @Autowired
    private PaymentService paymentService;
    @Autowired
    private EmailService emailService;
    @Value("${admin.email}")
    private String adminEmail;
    @Autowired
    private Environment env;

    private static final String PREFIX = "KPM-";
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyy"+"-"); // Format: DDMMYYYY
    private static final Random random = new Random();

    public String generateInvoiceNumber() {
        String date = dateFormat.format(new Date()); // Get current date in DDMMYYYY format
        int randomNumber = 100000 + random.nextInt(900000); // Generate a 6-digit random number
        return PREFIX + date + randomNumber;
    }

    @PostMapping("/place")
    public ResponseEntity<?> placeOrder(@RequestBody OrderDTO orderDTO) {
        try {
            if (orderDTO.getOrderItems() == null || orderDTO.getOrderItems().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "Order items cannot be null or empty."));
            }

            double totalOrderPrice = 0;
            List<OrderItem> orderItemList = new ArrayList<>();

            // Create Order entity
            Order order = new Order();
            order.setOrderStatus("PENDING");
            order.setPaymentStatus("NOT PAID");
            order.setOrderDate(LocalDate.now());
            order.setInvoiceNumber(generateInvoiceNumber());  // Ensure this method sets a valid invoice number
            order.setDeliveryDate(orderDTO.getDeliveryDate());
            order.setUser(userService.findUserById(orderDTO.getUserId()));
            order.setOrderAddress(addressService.findById(orderDTO.getAddressId()));

            for (OrderItemDTO itemDTO : orderDTO.getOrderItems()) {
                Product product = productService.findById(itemDTO.getProductId())
                        .orElseThrow(() -> new IllegalArgumentException("Product not found with ID: " + itemDTO.getProductId()));

                if (product.getStockQuantity() < itemDTO.getQuantity()) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                            .body(Map.of("error", "Not enough stock available for product: " + product.getName()));
                }

                // Create OrderItem for each item in orderDTO
                OrderItem orderItem = new OrderItem();
                orderItem.setOrder(order);
                orderItem.setProduct(product);
                orderItem.setQuantity(itemDTO.getQuantity());
                orderItem.setUnitPrice(product.getPrice());  // Set the unit price of the product
                orderItem.setTotalPrice(product.getPrice() * itemDTO.getQuantity());  // Set total price of this order item

                orderItemList.add(orderItem);

                // Calculate total order price
                totalOrderPrice += orderItem.getTotalPrice();

                // Update product stock
                product.setStockQuantity(product.getStockQuantity() - itemDTO.getQuantity());
                productService.saveProduct(product);
            }

            order.setAmount(totalOrderPrice);

            // Save the order and order items
            order.setOrderItemsLazy(orderItemList);

            // Create Razorpay order
            JSONObject razorpayOrder = paymentService.createOrder(totalOrderPrice);
            order.setRazorpayOrderId(razorpayOrder.getString("id"));

            // Save order in the repository
            orderRepository.save(order);

            return ResponseEntity.ok(razorpayOrder.toString());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("error", "Error placing order."));
        }
    }
    @PostMapping("/verifyPayment")
    public ResponseEntity<?> verifyPayment(@RequestBody Map<String, String> paymentDetails) {
        try {
            String razorpayOrderId = paymentDetails.get("orderId");
            String razorpayPaymentId = paymentDetails.get("paymentId");
            String razorpaySignature = paymentDetails.get("signature");

            // Verify the payment signature using Razorpay SDK or custom logic
            boolean isValid = paymentService.verifyPaymentSignature(razorpayOrderId, razorpayPaymentId, razorpaySignature);

            if (isValid) {
                // Retrieve the order by Razorpay Order ID
                Order order = orderService.findOrderByRazorpayOrderId(razorpayOrderId);
                if (order != null) {
                    // Update order and payment statuses
                    order.setOrderStatus("Yet to Dispatch");
                    order.setPaymentStatus("PAID");
                    order.setRazorpayPaymentId(razorpayPaymentId);
                    orderService.saveOrder(order);
                    // Send success email to the customer
                    String userEmail = order.getUser().getEmail();
                    String userName = order.getUser().getName();
                    String successEmailBody = "Dear " + userName + "<br><br>" +
                            "We’re pleased to let you know that your payment has been successfully received! Thank you for choosing <b>KPM Super Shopee</b>. Your order is now being processed, and we’re excited to get it ready for you.<br><br>" +
                            "<b>Order Details:<b><br><br>"+
                            " <b>Order Number : </b>   " + razorpayOrderId + ",<br>" +
                            " <b>Payment ID : </b> " + razorpayPaymentId + "<br>" +
                            " <b>Total Amount : </b>" + "₹"+order.getAmount()+"<br>"+
                            "<b>Order Date : </b>"+order.getOrderDate()+"<br>"+
                            "<b>Estimated Delivery Date :</b> "+order.getDeliveryDate()+"<br>"+
                            "<b>Order Status :</b> Yet to Dispatch<br><br>" +
                            "<b>Shipping Information</b> :<br>"+order.getOrderAddress()+"<br><br>"+
                            "If you have any questions or concerns about your order, feel free to reach out to us:<br>"+
                            "<b>Email :</b>shineorganicskpm@gmail.com"+"<br>"+
                            "<b>Phone : </b>+91 97915 47470"+"<br><br>"+
                            "Thank you again for choosing KPM Super Shopee. We’re dedicated to providing you with the best service and look forward to your feedback!<br><br>"+
                            "Warm Regards,  <br>" +
                            "<b>The KPM Super Shopee Team</b><br>";
                    emailService.sendEmail(userEmail, "✅ Payment Successful – Thank You for Shopping with KPM Super Shopee!", successEmailBody);

                    // Send email to admin with order details
                    String adminEmailBody = "Hello KPM Super Shopee Team,<br><br>"+
                            "A new order has been successfully placed and confirmed by the customer. Here are the details of the order:<br><br>"+
                            "<b>Order Details:</b><br>"+
                            "<b>Order Number :</b>"+razorpayOrderId+"<br>"+
                            "<b> Order Date :</b>"+order.getOrderDate()+"<br>"+
                            "Payment ID: " + razorpayPaymentId + "<br>" +
                            "<b> Total Amount Paid :</b>"+order.getAmount()+"<br><br>"+
                            "<b> Customer Information : </b><br>"+
                            "Customer Name: " + userName + "<br>" +
                            "Customer Email: " + userEmail + "<br>" +
                            "Order Status: Yet to Dispatch<br><br>" +
                            "Please proceed with the next steps to prepare the order for shipment. If any further information is needed, kindly reach out to the customer for clarification." +
                            "<br><br>"+
                            "Let’s ensure a smooth and timely delivery to maintain our commitment to excellent customer service!"+
                            "<br><br>"+
                            "Best<br>"+
                            "<b>KPM Super Shopee Notifications</b>";
                    emailService.sendEmail(adminEmail, "\uD83D\uDCE5 New Order Confirmed – "+ razorpayOrderId, adminEmailBody);

                    return ResponseEntity.ok("Payment verified successfully, order and payment statuses updated.");
                } else {
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Order not found with Razorpay Order ID: " + razorpayOrderId);
                }
            } else {
                // Send failure email to the customer
                String userEmail = paymentDetails.get("userEmail");
                String userName = paymentDetails.get("userName");
                if (userEmail != null && userName != null) {
                    String failureEmailBody = "Dear " + userName + ",<br>" +
                            "<br>" +
                            "We regret to inform you that your payment could not be verified. Please check your payment details or try again.<br><br>" +
                            "Order ID: " + razorpayOrderId + "<br>" +
                            "Payment ID: " + razorpayPaymentId + "<br>" +
                            "Status: Payment verification failed.<br><br>" +
                            "If you have any questions, please contact our support team.<br><br>" +
                            "Thank you for your understanding.";
                    emailService.sendEmail(userEmail, "Payment Verification Failed", failureEmailBody);
                }
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid payment signature.");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Payment verification failed.");
        }
    }
    @PutMapping("/{orderId}/status")
    public ResponseEntity<?> updateOrderStatus(@PathVariable Long orderId, @RequestBody String status) {
        try {
            // Clean up the status input
            status = status.trim().replaceAll("^\"|\"$", "");

            // Fetch the order first
            Order order = orderService.findOrderById(orderId); // Assuming you have a method to find by ID

            // Check if the order was fetched successfully
            if (order == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "Order not found"));
            }

            // Check if status change is "Canceled" and order is "Paid"
            if ("Canceled".equalsIgnoreCase(status) && "Paid".equalsIgnoreCase(order.getPaymentStatus())) {
                // Assuming you have the payment ID stored in the order (razorpayPaymentId)
                String razorpayPaymentId = order.getRazorpayPaymentId(); // Replace with actual field if different
                if (razorpayPaymentId != null && !razorpayPaymentId.isEmpty()) {
                    try {
                        // Call Razorpay API to process refund
                        Refund refund = paymentService.processRefund(razorpayPaymentId); // Replace with actual refund logic

                        // Update payment status to "Refunded"
                        order.setPaymentStatus("Refunded");
                        orderService.saveOrder(order);  // Save the updated order with "Refunded" status
                    } catch (Exception e) {
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                .body(Map.of("error", "Refund failed for order ID " + orderId));
                    }
                }
            }

            // Update the order status
            Order updatedOrder = orderService.updateOrderStatus(orderId, status);

            if ("Canceled".equalsIgnoreCase(status)) {
                if (order.getOrderItemsEager() == null || order.getOrderItemsEager().isEmpty()) {
                    // No order items to process
                } else {
                    for (OrderItem orderItem : order.getOrderItemsEager()) {
                        Product product = orderItem.getProduct();
                        int quantityPurchased = orderItem.getQuantity();

                        // Check if product is not null and has a valid quantity to restore
                        if (product != null && quantityPurchased > 0) {
                            product.setStockQuantity(product.getStockQuantity() + quantityPurchased);

                            // Save the product and verify if it's saved correctly
                            productService.saveProduct(product);
                        }
                    }
                }

                // Send cancellation email to the customer
                String customerEmail = order.getUser().getEmail(); // Assuming the email is stored in the order
                if (customerEmail != null && !customerEmail.isEmpty()) {
                    emailService.sendCancellationEmail(customerEmail, orderId);
                }
            }
            // Handle "Paid" status to process refund
            if ("PAID".equalsIgnoreCase(status)) {
                // Assuming you have the payment ID stored in the order (razorpayPaymentId)
                String razorpayPaymentId = order.getRazorpayPaymentId(); // Replace this with the correct field from your order
                if (razorpayPaymentId != null && !razorpayPaymentId.isEmpty()) {
                    try {
                        Refund refund = paymentService.processRefund(razorpayPaymentId); // Call Razorpay API to process refund
                        // Update payment status to "Refunded"
                        order.setPaymentStatus("Refunded");
                        orderService.saveOrder(order);  // Save the updated order with "Refunded" status
                    } catch (Exception e) {
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                .body(Map.of("error", "Refund failed for order ID " + orderId));
                    }
                }
            }
            return ResponseEntity.ok(updatedOrder);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("error", "An error occurred while updating the order."));
        }
    }
    @PostMapping("/verify")
    public ResponseEntity<?> verifyPaymentStatus(@RequestBody PaymentRequest paymentRequest) {
        try {
            JSONObject razorpayOrder = paymentService.fetchRazorpayOrder(paymentRequest.getOrderId());

            String paymentStatus = razorpayOrder.getString("status");

            if ("paid".equalsIgnoreCase(paymentStatus)) {
                return ResponseEntity.ok(Map.of("message", "Payment verified successfully!"));
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Payment verification failed."));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Error verifying payment: " + e.getMessage()));
        }
    }
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getOrdersByUser(@PathVariable Long userId) {
        try {
            List<Order> orders = orderService.getOrdersByUser(userId);
            // Convert Order list to OrderDTO list
            List<OrderDTO> orderDTOs = orders.stream()
                    .map(this::mapToDTO)
                    .collect(Collectors.toList());
            return ResponseEntity.ok(orderDTOs);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "An error occurred while fetching orders."));
        }
    }

    @GetMapping("/orders/{id}")
    public ResponseEntity<OrderDTO> getOrder(@PathVariable Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
        OrderDTO orderDTO = mapToDTO(order);
        return ResponseEntity.ok(orderDTO);
    }

    @PutMapping("/{orderId}/cancel")
    public ResponseEntity<?> cancelOrderWithRefund(@PathVariable Long orderId) {
        try {

            Order order = orderRepository.findById(orderId)
                    .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + orderId));

            if ("CANCELLED".equalsIgnoreCase(order.getOrderStatus())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Order is already cancelled."));
            }

            if ("DELIVERED".equalsIgnoreCase(order.getOrderStatus())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Order has already been delivered and cannot be cancelled."));
            }

            String razorpayPaymentId = order.getRazorpayPaymentId();

            if (razorpayPaymentId == null || razorpayPaymentId.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Razorpay payment ID not found for the order."));
            }


            Refund refund = paymentService.processRefund(razorpayPaymentId);


            if (refund != null && "processed".equalsIgnoreCase(refund.get("status"))) {

                dashboardService.reduceTotalSales(order.getAmount());
                order.setOrderStatus("CANCELLED");
                order.setPaymentStatus("REFUNDED");

                for (OrderItem orderItem : order.getOrderItemsEager()) {
                    Product product = orderItem.getProduct();

                    product.setStockQuantity(product.getStockQuantity() + orderItem.getQuantity());
                    productService.saveProduct(product);
                }
                orderRepository.save(order);

                // Send cancellation confirmation email to user
                String userEmail = order.getUser().getEmail();
                String userEmailBody = "Dear " + order.getUser().getName() + ",<br><br>    " +
                        "Your order has been successfully cancelled. Here are your order details:<br>" +
                        "<b>Invoice Number: </b>" + order.getInvoiceNumber() + "<br>" +
                        "<b>Refund Amount: </b>₹" + order.getAmount() + "<br>" +
                        "<b>Products:<br>";
                for (OrderItem item : order.getOrderItemsEager()) {
                    userEmailBody += "Product: " + item.getProduct().getName() + ", Quantity: " + item.getQuantity() + "<br>";
                }
                userEmailBody += "<br>Thank you for your understanding.";
                emailService.sendEmail(userEmail, " \uD83D\uDCE2 Delivery Canceled –  Order", userEmailBody);

                // Send cancellation notice to admin
                String adminEmail = env.getProperty("admin.email");
                StringBuilder adminEmailBody = new StringBuilder();
                adminEmailBody.append("Hello KPM Super Shopee Team,<br><br>"
                        +"The customer has canceled the delivery for the following order. Please review the details below:<br>"
                        +"<b>Order cancelled by: </b>").append(order.getUser().getName()).append("<br><br>");
                adminEmailBody.append("<b>Order Details:</b><br>");
                for (OrderItem item : order.getOrderItemsEager()) {
                    adminEmailBody.append("<b>Product: </b>").append(item.getProduct().getName())
                            .append(",<b> Quantity: </b>").append(item.getQuantity())
                            .append("<br>");
                }
                adminEmailBody.append("<br><b>Total Refund Amount: </b>").append(order.getAmount());
                adminEmailBody.append("Please initiate the necessary cancellation process. If a refund is applicable, proceed as per the standard refund guidelines.<br> Should any additional actions be required, kindly reach out to the customer for further assistance.<br><br>"
                        +"Let’s ensure all relevant teams are informed to update records accordingly.<br><br>"+"Best Regards,<br><b>KPM Super Shopee Notifications</b>");
                emailService.sendEmail(adminEmail, "Order Cancelled Notification", adminEmailBody.toString());

                return ResponseEntity.ok(Map.of("message", "Order has been successfully cancelled and refunded."));
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(Map.of("error", "Refund processing failed."));
            }
        } catch (ResourceNotFoundException e) {

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();  // Print full error trace for debugging
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "An error occurred while cancelling the order."));
        }
    }
    private OrderDTO mapToDTO(Order order) {
        OrderDTO dto = new OrderDTO();

        // Ensure you are using the correct getter methods for each field
        dto.setOrderId(order.getOrderId()); // Use the actual getter for order ID
        dto.setOrderStatus(order.getOrderStatus());
        dto.setAmount(order.getAmount());
        dto.setOrderDate(order.getOrderDate());
        dto.setDeliveryDate(order.getDeliveryDate());
        dto.setPaymentStatus(order.getPaymentStatus());
        dto.setInvoiceNumber(order.getInvoiceNumber());

        // Map userId and address details
        // Map userId and address details
        dto.setUserId(order.getUser().getId()); // Assuming you have getId() in User entity

        if (order.getOrderAddress() != null) {
            Address address = order.getOrderAddress();
            dto.setAddressId(address.getId()); // Assuming getId() in OrderAddress entity

            // Create AddressDto and map fields
            AddressDTO addressDto = new AddressDTO();
            addressDto.setId(address.getId());
            addressDto.setAddressLine1(address.getAddressLine1());
            addressDto.setCity(address.getCity());
            addressDto.setState(address.getState());
            addressDto.setZip(address.getZip());
            addressDto.setName(address.getName());
            addressDto.setAddressLine2(address.getAddressLine2());
            addressDto.setPhone(address.getPhone());
            addressDto.setType(address.getType());


            // Set the AddressDto in OrderDto
            dto.setAddress(addressDto);
        }

        // Map orderItems
        List<OrderItemDTO> orderItemsDTO = order.getOrderItemsEager().stream()
                .map(this::mapToDTO) // Call a method to map OrderItem to OrderItemDTO
                .collect(Collectors.toList());
        dto.setOrderItems(orderItemsDTO);

        return dto;
    }

    private OrderItemDTO mapToDTO(OrderItem orderItem) {
        OrderItemDTO itemDTO = new OrderItemDTO();




        ProductDTO productDTO = new ProductDTO();
        Product product = orderItem.getProduct(); // Assuming OrderItem has a getProduct() method
        productDTO.setId(product.getId());
        productDTO.setName(product.getName());
        productDTO.setDescription(product.getDescription());
        productDTO.setPrice(product.getPrice());
        productDTO.setSize(product.getSize());

        productDTO.setMainimage(baseUrl +"/"+ product.getMainimage());
        productDTO.setThumbnail(baseUrl +"/"+ product.getThumbnail());
        productDTO.setCategory(product.getCategory());

        productDTO.setMrp(product.getMrp());
        productDTO.setSuitable(product.getSuitable());
        productDTO.setSpecialLine(product.getSpecialLine());

        itemDTO.setProduct(productDTO);  // Set the entire product DTO
        itemDTO.setQuantity(orderItem.getQuantity());
        itemDTO.setUnitPrice(orderItem.getUnitPrice());
        itemDTO.setTotalPrice(orderItem.getTotalPrice());

        return itemDTO;
    }
    @GetMapping
    public ResponseEntity<?> getAllOrders() {
        try {
            List<Order> orders = orderService.getAllOrders();
            // Convert each Order entity to OrderDTO
            List<OrderDTO> orderDTOs = orders.stream()
                    .map(this::mapToDTO)  // Call mapToDTO for each order to map it to OrderDTO
                    .collect(Collectors.toList());
            return ResponseEntity.ok(orderDTOs);  // Return list of OrderDTOs as response
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "An error occurred while fetching orders."));
        }
    }

}