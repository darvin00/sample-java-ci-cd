package com.example.admin.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "address")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(cascade = {CascadeType.MERGE, CascadeType.REFRESH})
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference // Prevents infinite recursion
    private User user;

    @NotBlank(message = "Name is required")
    @Column(columnDefinition = "LONGTEXT")
    private String name;

    @NotBlank(message = "Type is required")
    @Column(columnDefinition = "LONGTEXT")
    private String type;

    @NotBlank(message = "Phone number is required")
    @Pattern(regexp = "\\d{10}", message = "Phone number must be 10 digits")
    private String phone;

    @NotBlank(message = "Address line 1 is required")
    @Column(columnDefinition = "LONGTEXT")
    private String addressLine1;

    @Column(columnDefinition = "LONGTEXT")
    private String addressLine2;


    @NotBlank(message = "City is required")
    @Column(columnDefinition = "LONGTEXT")
    private String city;

    @NotBlank(message = "State is required")
    @Column(columnDefinition = "LONGTEXT")
    private String state;

    @NotBlank(message = "Zip code is required")
    @Pattern(regexp = "\\d{5}", message = "Zip code must be 5 digits")
    private String zip;

    // Default constructor
    public Address() {}

    // Constructor with all fields
    public Address(User user, String name, String type, String phone, String addressLine1, String addressLine2, String city, String state, String zip) {
        this.user = user;
        this.name = name;
        this.type = type;
        this.phone = phone;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.city = city;
        this.state = state;
        this.zip = zip;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getAddressLine1() { return addressLine1; }
    public void setAddressLine1(String addressLine1) { this.addressLine1 = addressLine1; }
    public String getAddressLine2() { return addressLine2; }
    public void setAddressLine2(String addressLine2) { this.addressLine2 = addressLine2; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public String getState() { return state; }
    public void setState(String state) { this.state = state; }
    public String getZip() { return zip; }
    public void setZip(String zip) { this.zip = zip; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Address address = (Address) o;
        return id != null ? id.equals(address.id) : address.id == null;
    }
    @Override
    public String toString() {
        StringBuilder addressBuilder = new StringBuilder();
        addressBuilder.append(name).append("\n")
                .append(phone).append("\n").append(addressLine1).append(", ");

        if (addressLine2 != null && !addressLine2.isEmpty()) {
            addressBuilder.append(addressLine2).append(", ");
        }

        addressBuilder
                .append(city).append(", ")
                .append(state).append(" - ")
                .append(zip);

        return addressBuilder.toString();
    }



    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
