package com.example.admin.DTO;

import java.util.List;

public class FavoriteProductDTO {
    private Long id;
    private Boolean favorited;
    private Integer rating;
    private Boolean shine;
    private Boolean sheShine;
    private String subcategory;
    private String category;
    private String mainImage;
    private List<CardDTO> cards;
    private List<String> images;
    private List<String> threeDImages;
    private String thumbnail;
    private String title;
    private String name;
    private String benefit;
    private String suitable;
    private String description;
    private String keyBenefit;
    private String howToUse;
    private String ingredients;
    private String size;
    private Double mrp;
    private Double price;
    private Integer stockQuantity;
    private Double discount;
    private Double averageRating;
    private Boolean feature;
    private Boolean trend;
    private Boolean special;
    private String specialLine;
    private String color;
    private List<ReviewDto> reviews;

    public FavoriteProductDTO(Long id, Boolean favorited, Boolean shine,
                              Boolean sheShine, String subcategory, String category,
                              String mainImage, List<CardDTO> cards, List<String> images,
                              List<String> threeDImages, String thumbnail, String title,
                              String name, String benefit, String suitable,
                              String description, String keyBenefit, String howToUse,
                              String ingredients, String size, Double mrp,
                              Double price, Integer stockQuantity, Double discount,
                              Double averageRating, Boolean feature, Boolean trend,
                              Boolean special, String specialLine, String color) {
        this.id = id;
        this.favorited = favorited;
        this.rating = rating;
        this.shine = shine;
        this.sheShine = sheShine;
        this.subcategory = subcategory;
        this.category = category;
        this.mainImage = mainImage;
        this.cards = cards;
        this.images = images;
        this.threeDImages = threeDImages;
        this.thumbnail = thumbnail;
        this.title = title;
        this.name = name;
        this.benefit = benefit;
        this.suitable = suitable;
        this.description = description;
        this.keyBenefit = keyBenefit;
        this.howToUse = howToUse;
        this.ingredients = ingredients;
        this.size = size;
        this.mrp = mrp;
        this.price = price;
        this.stockQuantity = stockQuantity;
        this.discount = discount;
        this.averageRating = averageRating;
        this.feature = feature;
        this.trend = trend;
        this.special = special;
        this.specialLine = specialLine;
        this.color = color;
    }

    public FavoriteProductDTO(Long id, Boolean favorited, Boolean shine, Boolean sheShine, String subcategory, String category, String mainImage, List<CardDTO> cards, String s, String s1, String thumbnail, String title, String name, String benefit, String suitable, String description, String keybenefit, String howToUse, String ingredients, String size, Double mrp, Double price, Integer stockQuantity, Double discount, Double averageRating, Boolean feature, Boolean trend, Boolean special, String specialLine, String color) {
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getFavorited() {
        return favorited;
    }

    public void setFavorited(Boolean favorited) {
        this.favorited = favorited;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public Boolean getShine() {
        return shine;
    }

    public void setShine(Boolean shine) {
        this.shine = shine;
    }

    public Boolean getSheShine() {
        return sheShine;
    }

    public void setSheShine(Boolean sheShine) {
        this.sheShine = sheShine;
    }

    public String getSubcategory() {
        return subcategory;
    }

    public void setSubcategory(String subcategory) {
        this.subcategory = subcategory;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getMainImage() {
        return mainImage;
    }

    public void setMainImage(String mainImage) {
        this.mainImage = mainImage;
    }

    public List<CardDTO> getCards() {
        return cards;
    }

    public void setCards(List<CardDTO> cards) {
        this.cards = cards;
    }

    public List<String> getImages() {
        return images;
    }

    public void setImages(List<String> images) {
        this.images = images;
    }

    public List<String> getThreeDImages() {
        return threeDImages;
    }

    public void setThreeDImages(List<String> threeDImages) {
        this.threeDImages = threeDImages;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBenefit() {
        return benefit;
    }

    public void setBenefit(String benefit) {
        this.benefit = benefit;
    }

    public String getSuitable() {
        return suitable;
    }

    public void setSuitable(String suitable) {
        this.suitable = suitable;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getKeyBenefit() {
        return keyBenefit;
    }

    public void setKeyBenefit(String keyBenefit) {
        this.keyBenefit = keyBenefit;
    }

    public String getHowToUse() {
        return howToUse;
    }

    public void setHowToUse(String howToUse) {
        this.howToUse = howToUse;
    }

    public String getIngredients() {
        return ingredients;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public Double getMrp() {
        return mrp;
    }

    public void setMrp(Double mrp) {
        this.mrp = mrp;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getStockQuantity() {
        return stockQuantity;
    }

    public void setStockQuantity(Integer stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Double getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(Double averageRating) {
        this.averageRating = averageRating;
    }

    public Boolean getFeature() {
        return feature;
    }

    public void setFeature(Boolean feature) {
        this.feature = feature;
    }

    public Boolean getTrend() {
        return trend;
    }

    public void setTrend(Boolean trend) {
        this.trend = trend;
    }

    public Boolean getSpecial() {
        return special;
    }

    public void setSpecial(Boolean special) {
        this.special = special;
    }

    public String getSpecialLine() {
        return specialLine;
    }

    public void setSpecialLine(String specialLine) {
        this.specialLine = specialLine;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public List<ReviewDto> getReviews() {
        return reviews;
    }

    public void setReviews(List<ReviewDto> reviews) {
        this.reviews = reviews;
    }

    @Override
    public String toString() {
        return "FavoriteProductDTO{" +
                "id=" + id +
                ", favorited=" + favorited +
                ", rating=" + rating +
                ", shine=" + shine +
                ", sheShine=" + sheShine +
                ", subcategory='" + subcategory + '\'' +
                ", category='" + category + '\'' +
                ", mainImage='" + mainImage + '\'' +
                ", cards=" + cards +
                ", images=" + images +
                ", threeDImages=" + threeDImages +
                ", thumbnail='" + thumbnail + '\'' +
                ", title='" + title + '\'' +
                ", name='" + name + '\'' +
                ", benefit='" + benefit + '\'' +
                ", suitable='" + suitable + '\'' +
                ", description='" + description + '\'' +
                ", keyBenefit='" + keyBenefit + '\'' +
                ", howToUse='" + howToUse + '\'' +
                ", ingredients='" + ingredients + '\'' +
                ", size='" + size + '\'' +
                ", mrp=" + mrp +
                ", price=" + price +
                ", stockQuantity=" + stockQuantity +
                ", discount=" + discount +
                ", averageRating=" + averageRating +
                ", feature=" + feature +
                ", trend=" + trend +
                ", special=" + special +
                ", specialLine='" + specialLine + '\'' +
                ", color='" + color + '\'' +
                ", reviews=" + reviews +
                '}';
    }
}
