package com.example.admin.enums;

public enum PaymentStatus {
    PENDING, COMPLETED, FAILED
}