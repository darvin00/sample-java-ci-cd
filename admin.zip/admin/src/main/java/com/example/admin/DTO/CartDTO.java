package com.example.admin.DTO;

public class CartDTO {
}
