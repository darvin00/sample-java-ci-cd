import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-N6VPEYGW.js";
import "./chunk-RT3VED3B.js";
import "./chunk-LGFUPXSJ.js";
import "./chunk-WTPCWF74.js";
import "./chunk-6B4OZPVK.js";
import "./chunk-IHFTBKYS.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-LJ4WON5P.js";
import "./chunk-Z7T2ZQFH.js";
import "./chunk-L3GQMXDF.js";
import "./chunk-YLN5H2NX.js";
import "./chunk-N2AHOJJ2.js";
import "./chunk-NQ4HTGF6.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
