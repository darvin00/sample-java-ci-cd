import { AddAddressComponent } from './add-address.component'

describe('AddAddressComponent', () => {
  // it('should mount', () => {
  //   cy.mount(AddAddressComponent)
  // })
})