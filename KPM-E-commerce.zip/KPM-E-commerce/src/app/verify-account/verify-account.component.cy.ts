import { VerifyAccountComponent } from './verify-account.component'

describe('VerifyAccountComponent', () => {
  it('should mount', () => {
    cy.mount(VerifyAccountComponent)
  })
})