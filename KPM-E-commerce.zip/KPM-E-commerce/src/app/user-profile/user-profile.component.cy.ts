import { UserProfileComponent } from './user-profile.component'

describe('UserProfileComponent', () => {
  it('should mount', () => {
    cy.mount(UserProfileComponent)
  })
})