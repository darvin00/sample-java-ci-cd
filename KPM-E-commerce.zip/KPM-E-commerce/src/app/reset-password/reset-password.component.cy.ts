import { ResetPasswordComponent } from './reset-password.component'

describe('ResetPasswordComponent', () => {
  it('should mount', () => {
    cy.mount(ResetPasswordComponent)
  })
})