import { LoginComponent } from './login.component'

describe('LoginComponent', () => {
  it('should mount', () => {
    cy.mount(LoginComponent)
  })
})