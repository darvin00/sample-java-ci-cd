import { AboutComponent } from './about.component'

describe('AboutComponent', () => {
  it('should mount', () => {
    cy.mount(AboutComponent)
  })
})