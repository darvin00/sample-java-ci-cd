import { PaymentComponent } from './payment.component'

describe('PaymentComponent', () => {
  it('should mount', () => {
    cy.mount(PaymentComponent)
  })
})