import { ContactComponent } from './contact.component'

describe('ContactComponent', () => {
  it('should mount', () => {
    cy.mount(ContactComponent)
  })
})