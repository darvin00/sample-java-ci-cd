import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Cancellation-and-Refund',
  templateUrl: './Cancellation-and-Refund.component.html',
  styleUrls: ['./Cancellation-and-Refund.component.scss']
})
export class CancellationAndRefundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
