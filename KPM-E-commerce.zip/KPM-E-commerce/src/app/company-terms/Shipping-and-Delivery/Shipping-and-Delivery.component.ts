import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Shipping-and-Delivery',
  templateUrl: './Shipping-and-Delivery.component.html',
  styleUrls: ['./Shipping-and-Delivery.component.scss']
})
export class ShippingAndDeliveryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
