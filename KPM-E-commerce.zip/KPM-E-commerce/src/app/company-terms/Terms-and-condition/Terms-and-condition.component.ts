import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Terms-and-condition',
  templateUrl: './Terms-and-condition.component.html',
  styleUrls: ['./Terms-and-condition.component.scss']
})
export class TermsAndConditionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
