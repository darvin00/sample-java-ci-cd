import { SearchBarComponent } from './search-bar.component'

describe('SearchBarComponent', () => {
  it('should mount', () => {
    cy.mount(SearchBarComponent)
  })
})