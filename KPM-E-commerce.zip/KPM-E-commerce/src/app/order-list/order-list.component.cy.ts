import { OrderListComponent } from './order-list.component'

describe('OrderListComponent', () => {
  it('should mount', () => {
    cy.mount(OrderListComponent)
  })
})