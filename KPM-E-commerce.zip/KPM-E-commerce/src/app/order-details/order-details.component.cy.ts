import { OrderDetailsComponent } from './order-details.component'

describe('OrderDetailsComponent', () => {
  it('should mount', () => {
    cy.mount(OrderDetailsComponent)
  })
})