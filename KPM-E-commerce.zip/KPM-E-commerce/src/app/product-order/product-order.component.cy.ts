import { ProductOrderComponent } from './product-order.component'

describe('ProductOrderComponent', () => {
  it('should mount', () => {
    cy.mount(ProductOrderComponent)
  })
})