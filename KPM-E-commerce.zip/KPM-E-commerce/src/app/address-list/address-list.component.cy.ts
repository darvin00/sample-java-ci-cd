import { AddressListComponent } from './address-list.component'

describe('AddressListComponent', () => {
  it('should mount', () => {
    cy.mount(AddressListComponent)
  })
})