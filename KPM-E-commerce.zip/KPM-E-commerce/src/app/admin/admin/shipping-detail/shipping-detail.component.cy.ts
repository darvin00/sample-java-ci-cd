import { ShippingDetailComponent } from './shipping-detail.component'

describe('ShippingDetailComponent', () => {
  it('should mount', () => {
    cy.mount(ShippingDetailComponent)
  })
})