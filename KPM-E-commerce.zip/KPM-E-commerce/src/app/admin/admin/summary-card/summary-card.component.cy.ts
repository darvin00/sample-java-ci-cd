import { SummaryCardComponent } from './summary-card.component'

describe('SummaryCardComponent', () => {
  it('should mount', () => {
    cy.mount(SummaryCardComponent)
  })
})