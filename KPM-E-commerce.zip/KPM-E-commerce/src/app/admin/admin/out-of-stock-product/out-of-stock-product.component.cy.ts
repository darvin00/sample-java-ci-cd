import { OutOfStockProductComponent } from './out-of-stock-product.component'

describe('OutOfStockProductComponent', () => {
  it('should mount', () => {
    cy.mount(OutOfStockProductComponent)
  })
})