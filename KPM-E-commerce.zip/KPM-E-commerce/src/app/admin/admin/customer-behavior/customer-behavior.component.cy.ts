import { CustomerBehaviorComponent } from './customer-behavior.component'

describe('CustomerBehaviorComponent', () => {
  it('should mount', () => {
    cy.mount(CustomerBehaviorComponent)
  })
})