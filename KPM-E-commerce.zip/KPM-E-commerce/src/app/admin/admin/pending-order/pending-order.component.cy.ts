import { PendingOrderComponent } from './pending-order.component'

describe('PendingOrderComponent', () => {
  it('should mount', () => {
    cy.mount(PendingOrderComponent)
  })
})