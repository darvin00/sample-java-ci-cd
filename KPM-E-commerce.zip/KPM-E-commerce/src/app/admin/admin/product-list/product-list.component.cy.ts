import { ProductListComponent } from './product-list.component'

describe('ProductListComponent', () => {
  it('should mount', () => {
    cy.mount(ProductListComponent)
  })
})