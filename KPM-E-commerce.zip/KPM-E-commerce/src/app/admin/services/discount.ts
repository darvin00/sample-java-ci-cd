export class Discount {
  code: any;
  endDate: any;
amount: any;
description: any;
}
