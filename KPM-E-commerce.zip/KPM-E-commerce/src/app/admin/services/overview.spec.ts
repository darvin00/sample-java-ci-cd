import { Overview } from './overview';

describe('Overview', () => {
  it('should create an instance', () => {
    expect(new Overview()).toBeTruthy();
  });
});
