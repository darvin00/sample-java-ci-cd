
    export interface OverviewData {
        totalProducts: number;
        totalOrders: number;
        totalCustomers: number;
      }
      

