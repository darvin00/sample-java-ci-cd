export interface Order {
  id: number;
  productName: string;
  quantity: number;
  status: string;
}