// src/app/admin/models/customer.model.ts
export interface Customer {
  id?: number;
  name: string;
  title: string;
  text: string;
}