import { UserProfile } from './user-profile.model';

describe('UserProfile', () => {
  it('should create an instance', () => {
    expect(new UserProfile()).toBeTruthy();
  });
});
