import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shine-footer',
  templateUrl: './shine-footer.component.html',
  styleUrls: ['./shine-footer.component.scss']
})
export class ShineFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
