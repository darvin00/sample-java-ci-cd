import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shine-card',
  templateUrl: './shine-card.component.html',
  styleUrls: ['./shine-card.component.scss']
})
export class ShineCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
