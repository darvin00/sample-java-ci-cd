import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productExplain',
  templateUrl: './productExplain.component.html',
  styleUrls: ['./productExplain.component.scss']
})
export class ProductExplainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
