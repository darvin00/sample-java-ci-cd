import { CartComponent } from './cart.component'

describe('CartComponent', () => {
  it('should mount', () => {
    cy.mount(CartComponent)
  })
})