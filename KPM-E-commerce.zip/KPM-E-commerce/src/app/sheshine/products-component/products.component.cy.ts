import { ProductsComponent } from './products.component'

describe('ProductsComponent', () => {
  it('should mount', () => {
    cy.mount(ProductsComponent)
  })
})