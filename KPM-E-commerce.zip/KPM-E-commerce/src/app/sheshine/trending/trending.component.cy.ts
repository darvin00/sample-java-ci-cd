import { TrendingComponent } from './trending.component'

describe('TrendingComponent', () => {
  it('should mount', () => {
    cy.mount(TrendingComponent)
  })
})