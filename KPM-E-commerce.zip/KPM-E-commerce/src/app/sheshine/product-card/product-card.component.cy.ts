import { ProductCardComponent } from './product-card.component'

describe('ProductCardComponent', () => {
  it('should mount', () => {
    cy.mount(ProductCardComponent)
  })
})