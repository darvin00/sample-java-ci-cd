import { FeatureComponent } from './feature.component'

describe('FeatureComponent', () => {
  it('should mount', () => {
    cy.mount(FeatureComponent)
  })
})