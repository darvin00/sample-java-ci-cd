import { SpecialComponent } from './special.component'

describe('SpecialComponent', () => {
  it('should mount', () => {
    cy.mount(SpecialComponent)
  })
})