import { Component } from '@angular/core';

@Component({
  selector: 'app-testmonial',
  templateUrl: './testmonial.component.html',
  styleUrl: './testmonial.component.scss'
})
export class TestmonialComponent {

}
