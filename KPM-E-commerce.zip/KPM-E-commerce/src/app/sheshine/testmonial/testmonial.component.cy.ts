import { TestmonialComponent } from './testmonial.component'

describe('TestmonialComponent', () => {
  it('should mount', () => {
    cy.mount(TestmonialComponent)
  })
})