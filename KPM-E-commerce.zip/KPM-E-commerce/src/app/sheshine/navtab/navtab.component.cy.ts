import { NavtabComponent } from './navtab.component'

describe('NavtabComponent', () => {
  it('should mount', () => {
    cy.mount(NavtabComponent)
  })
})