import { HomeComponent } from './home.component'

describe('HomeComponent', () => {
  it('should mount', () => {
    cy.mount(HomeComponent)
  })
})